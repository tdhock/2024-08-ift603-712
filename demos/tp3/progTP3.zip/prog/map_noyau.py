# -*- coding: utf-8 -*-

#####
# Vos Noms (Vos Matricules) .~= À MODIFIER =~.
###

import numpy as np
import matplotlib.pyplot as plt


class MAPnoyau:
    def __init__(
        self, lamb=0.2, sigma_square=1.06, b=1.0,
        c=0.1, d=1.0, M=2, noyau='rbf'
    ):
        """
        Classe effectuant une classification 2D 2 classes à l'aide
        de la méthode à noyau.

        lamb: coefficiant de régularisation L2
        sigma_square: paramètre du noyau rbf
        b, d: paramètres du noyau sigmoidal
        M,c: paramètres du noyau polynomial
        noyau: rbf, lineaire, olynomial ou sigmoidal
        """

        self.lamb = lamb
        self.a = None
        self.sigma_square = sigma_square
        self.M = M
        self.c = c
        self.b = b
        self.d = d
        self.noyau = noyau

        if self.noyau == 'rbf':
            self.noyau_fn = self.rbf
        elif self.noyau == 'sigmoidal':
            self.noyau_fn = self.sigmoidal
        elif self.noyau == 'polynomial':
            self.noyau_fn = self.polynomial
        elif self.noyau == 'lineaire':
            self.noyau_fn = self.lineaire

        self.x_train = None

    def rbf(self, x, x_prime):
        """ Noyau RBF tel que présenté dans l'énoncé.

        NOTE: Devrait fonctionner autant pour l'entraînement que
        la prédiction sans condition particulière.

        NOTE: S'effectue sans boucles.
        """

        # AJOUTER CODE ICI
        return x

    def sigmoidal(self, x, x_prime):
        """ Noyau sigmoidal tel que présenté dans l'énoncé.

        NOTE: Devrait fonctionner autant pour l'entraînement que
        la prédiction sans condition particulière.

        NOTE: S'effectue sans boucles.
        """

        # AJOUTER CODE ICI
        return x

    def polynomial(self, x, x_prime):
        """ Noyau polynomial tel que présenté dans l'énoncé.

        NOTE: Devrait fonctionner autant pour l'entraînement que
        la prédiction sans condition particulière.

        NOTE: S'effectue sans boucles.
        """

        # AJOUTER CODE ICI
        return x

    def lineaire(self, x, x_prime):
        """ Noyau linéaire tel que présenté dans l'énoncé.

        NOTE: Devrait fonctionner autant pour l'entraînement que
        la prédiction sans condition particulière.

        NOTE: S'effectue sans boucles.
        """

        # AJOUTER CODE ICI
        return x

    def entrainement(self, x_train, t_train):
        """
        Entraîne une méthode d'apprentissage à noyau de type Maximum a
        posteriori (MAP) avec un terme d'attache aux données de type
        "moindre carrés" et un terme de lissage quadratique (voir
        Eq.(1.67) et Eq.(6.2) du livre de Bishop).  La variable x_train
        contient les entrées (un tableau 2D Numpy, où la n-ième rangée
        correspond à l'entrée x_n) et des cibles t_train (un tableau 1D Numpy
        où le n-ième élément correspond à la cible t_n).

        L'entraînement doit utiliser un noyau de type RBF, lineaire, sigmoidal,
        ou polynomial (spécifié par ''self.noyau'') et dont les parametres
        sont contenus dans les variables self.sigma_square, self.c, self.b,
        self.d et self.M et un poids de régularisation spécifié par
        ``self.lamb``.

        Cette méthode doit assigner le champs ``self.a`` tel que spécifié à
        l'equation 6.8 du livre de Bishop et garder en mémoire les données
        d'apprentissage dans ``self.x_train``

        NOTE: Vous devez utiliser self.noyau_fn pour calculer le noyau.

        NOTE: Vous devez utiliser deux boucles imbriquées pour calculer la
        matrice de Gramm.
        """

        self.a = None
        self.x_train = x_train

        # AJOUTER CODE ICI

    def prediction(self, x):
        """
        Retourne la prédiction pour une ou plusieurs entrées representée par un
        tableau 2D Numpy ``x``.

        Cette méthode suppose que la méthode ``entrainement()`` a préalablement
        été appelée. Elle doit utiliser le champs ``self.a`` afin de calculer
        la prédiction y(x) (équation 6.9).

        NOTE : Puisque nous utilisons cette classe pour faire de la
        classification binaire, la prediction est +1 lorsque y(x)>0.5 et 0
        sinon.

        NOTE: Vous devez utiliser self.noyau_fn pour calculer le noyau.

        NOTE: Vous devez utiliser une ou deux boucles pour faire la prédiction.

        """
        # AJOUTER CODE ICI
        return 0.0

    def erreur(self, t, prediction):
        """
        Retourne la différence au carré entre
        la cible ``t`` et la prédiction ``prediction``.
        """
        # AJOUTER CODE ICI
        return 0.0

    def validation_croisee(self, x_tab, t_tab):
        """
        Cette fonction trouve les meilleurs hyperparametres
        ``self.sigma_square``, ``self.c`` et ``self.M`` (tout dépendant du
        noyau selectionné) et ``self.lamb`` avec une validation croisée de type
        "k-fold" où k=10 avec les données contenues dans x_tab et t_tab.  Une
        fois les meilleurs hyperparamètres trouvés, le modèle est entraîné une
        dernière fois.

        SUGGESTION: Les valeurs de ``self.sigma_square`` et ``self.lamb`` à
        explorer vont de 0.000000001 à 2, les valeurs de ``self.c`` de 0 à 5,
        les valeurs de ''self.b'' et ''self.d'' de 0.00001 à 0.01 et ``self.M``
        de 2 à 6.

        NOTE: S'il était bien implémenté, une bonne partie de votre code
        effectuant la recherche d'hyperparamètres au travail pratique 1
        est réutilisable ici.

        NOTE: Votre code aura nécéssairement quatre if-else sur le noyau
        choisi et une boucle sur chaque "fold" + une boucle par hyperparamètre
        à trouver. Par contre, vous pouvez réduire la duplication de code en
        vous concevant une ou des méthodes qui effectuent la validation pour
        un "fold" (et l'entraînement avec les autres) agnostiques au noyau
        choisi et ses paramètres.
        """
        # AJOUTER CODE ICI

    def affichage(self, x_tab, t_tab):

        # Affichage
        ix = np.arange(x_tab[:, 0].min(), x_tab[:, 0].max(), 0.1)
        iy = np.arange(x_tab[:, 1].min(), x_tab[:, 1].max(), 0.1)
        iX, iY = np.meshgrid(ix, iy)
        x_vis = np.hstack([iX.reshape((-1, 1)), iY.reshape((-1, 1))])
        contour_out = np.array([self.prediction(x[None, :]) for x in x_vis])
        contour_out = contour_out.reshape(iX.shape)

        plt.contourf(iX, iY, contour_out > 0.5)
        plt.scatter(x_tab[:, 0], x_tab[:, 1], s=(
            t_tab + 0.5) * 100, c=t_tab, edgecolors='y')
        plt.show()

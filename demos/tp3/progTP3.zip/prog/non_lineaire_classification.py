# -*- coding: utf-8 -*-
"""
Execution dans un terminal

Exemple:
   python non_lineaire_classification.py rbf 100 200 0 0

Vos Noms (Vos Matricules) .~= À MODIFIER =~.
"""

import argparse
import numpy as np

import gestion_donnees as gd

from map_noyau import MAPnoyau

example = '''Exemples:

    python non_lineaire_classification.py rbf 200 200 --vc
    python non_lineaire_classification.py lineaire 20 20 --lin
'''


def get_arguments():
    parser = argparse.ArgumentParser(
        description='Régression polynomiale.',
        epilog=example,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('type_noyau',
                        choices=['rbf', 'sigmoidal', 'polynomial', 'lineaire'],
                        default='lineaire',
                        help='Choix de la fonction générant les données.')
    parser.add_argument('nb_train', type=int, default=280,
                        help='Nombre de données d\'entraînement.')
    parser.add_argument('nb_test', type=int, default=280,
                        help='Nombre de données de test.')
    parser.add_argument('--lin', action='store_true',
                        help='Données linéairement séparables, ou pas.')
    parser.add_argument('--vc', action='store_true',
                        help='Validation croisée.')
    return parser


def main():
    p = get_arguments()
    args = p.parse_args()

    type_noyau = args.type_noyau
    nb_train = args.nb_train
    nb_test = args.nb_test
    lin_sep = args.lin
    vc = args.vc

    # On génère les données d'entraînement et de test
    generateur_donnees = gd.GestionDonnees(nb_train, nb_test, lin_sep)
    [x_train, t_train, x_test, t_test] = generateur_donnees.generer_donnees()

    # On entraine le modèle
    mp = MAPnoyau(noyau=type_noyau)

    if vc is False:
        mp.entrainement(x_train, t_train)
    else:
        mp.validation_croisee(x_train, t_train)

    # Prédictions sur les ensembles d'entraînement et de test
    predictions_entrainement = mp.prediction(x_train)
    print("Erreur d'entrainement = ", 100 *
          np.mean(mp.erreur(t_train, predictions_entrainement)), "%")

    predictions_test = mp.prediction(x_test)
    print("Erreur de test = ", 100 *
          np.mean(mp.erreur(t_test, predictions_test)), "%")

    # Affichage
    mp.affichage(x_test, t_test)


if __name__ == "__main__":
    main()
